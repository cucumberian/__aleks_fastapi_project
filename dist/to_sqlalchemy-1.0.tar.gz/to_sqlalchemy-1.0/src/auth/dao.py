from dao.base import BaseDAO
from models.user import User

class UserDAO(BaseDAO):
   model = User